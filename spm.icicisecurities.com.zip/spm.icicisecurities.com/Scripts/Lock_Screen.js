﻿function skm_LockScreen() {

    var lock = document.getElementById('skm_LockPane');

    if (lock)
        lock.className = 'LockOn';

    lock.innerHTML = "<h3>Please Wait.....</h3>";
} 